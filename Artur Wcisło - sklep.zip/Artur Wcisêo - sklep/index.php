<?php

$servername = "localhost";
$username = "root";
$password = ""; 
$dbname = "sklep";


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Błąd połączenia: " . $conn->connect_error);
}


$query1 = "SELECT nazwa FROM towary WHERE promocja = 1";
$result1 = $conn->query($query1);

if ($result1->num_rows > 0) {
    echo "<ol type='a'>";
    while ($row = $result1->fetch_assoc()) {
        echo "<li>" . $row["nazwa"] . "</li>";
    }
    echo "</ol>";
    } else {
        echo "Brak danych do wyświetlenia";
    }

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $selected_product = $_POST['products'];

    $query2 = "SELECT cena FROM towary WHERE nazwa = '$selected_product'"; 

    $result2 = $conn->query($query2);

    if ($result2->num_rows > 0) {
        $row = $result2->fetch_assoc();
        $cena_produktu = $row['cena'];
        $cena_promocja = $cena_produktu * 0.7; 
     
        echo "<div>";
        echo "Cena regularna: " . $cena_produktu . "<br>";
        echo "Cena w promocji 30%: " . $cena_promocja;
        echo "</div>";
    } else {
        echo "Brak wyników.";
    }
}


$conn->close();
?>