<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Sklep dla uczniów</title>
    <link rel="stylesheet" href="styl.css">
</head>
<body>
    <?php
    $servername = 'localhost';
    $username = 'root';
    $password = '';
    $dbname = 'sklep';

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connect failed: " . $conn->connect_error);
    }

    ?>
    <div id="baner">
        <h1>Dzisiejsze promocje naszego sklepu</h1>
    </div>
    <div id="lewy">
        <h2>Taniej o 30%</h2>
        <?php
            $query1 = "SELECT nazwa FROM towary WHERE promocja = 1";
            $result1 = $conn->query($query1);

            if ($result1->num_rows > 0) {
                echo "<ol type='a'>";
                while ($row = $result1->fetch_assoc()) {
                    echo "<li>" . $row["nazwa"] . "</li>";
                }
                echo "</ol>";
                } else {
                    echo "Brak danych do wyświetlenia";
                }
        ?>
    </div>
    <div id="środkowy">
        <h2>Sprawdź cenę</h2>
        <form action="index.php" method="post">
            <select name="towary">
                <option value="gumka">Gumka do mazania</option>
                <option value="cienkopis">Cienkopis</option>
                <option value="pisaki">Pisaki 60 szt.</option>
                <option value="markery">Markery 4 szt.</option>
            </select>
            <input type="submit" value="WYBIERZ">
            
        <?php
            if (isset($_POST['nazwa_towaru'])) {
                $nazwa_towaru = $_POST['nazwa_towaru'];
            
                // Zapytanie 2: Modyfikacja i pobranie danych
                $query2 = "SELECT cena FROM tabela2 WHERE nazwa_towaru = ?";
                $stmt = $conn->prepare($query2);
                $stmt->bind_param("s", $nazwa_towaru);
                $stmt->execute();
                $result2 = $stmt->get_result();
            
                if ($result2->num_rows > 0) {
                    $row = $result2->fetch_assoc();
                    $cena = $row['cena'];
                    $cena_promocyjna = $cena * 0.7;
            
                    // Wyświetlenie danych w formacie z obrazu 2
                    echo "<h2>Wyniki:</h2>";
                    echo "<p>Nazwa towaru: $nazwa_towaru</p>";
                    echo "<p>Cena: $cena zł</p>";
                    echo "<p>Cena promocyjna: $cena_promocyjna zł</p>";
                } else {
                    echo "Brak danych dla wybranego towaru";
                }
            }
            
            // Zamknięcie połączenia z bazą danych
            $conn->close();
        ?>
        </form>
    </div>
    <div id="prawy">
        <h2>Kontakt</h2>
        <p>e-mail:</p><a href="mailto:bok@sklep.pl">bok@sklep.pl</a></p>
        <img src="promocja.png" alt="promocja">
    </div>
    <div id="stopka">
        <h4>Autor strony: Artur Wcisło</h4>
    </div>
</body>
</html>